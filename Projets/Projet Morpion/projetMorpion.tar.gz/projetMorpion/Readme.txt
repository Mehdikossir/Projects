*Pour compiler il suffit de vous placez dans le répertoire du projet et tapez make sur le terminal.
*Pour voir les tests il suffit de vous placez dans le répertoire test et tapez ./test<nom de ce que vous voulez tester>
