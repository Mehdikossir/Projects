#ifndef __FONCTIONS_PRINCIPALES__
#define __FONCTIONS_PRINCIPALES__
#include <string.h>
#include "Case.h"
#include"Grille.h"
#include "Booleen.h"
#include "ajoutercase.h"

static unsigned int nbDePartie;
void gagnantExiste(Grille grille,ValeurCase *joueurGagnant,Booleen *estGagnant);
Booleen grillePleine(Grille grille);
Booleen testFinJeu(Grille grille);
void enregistrerScore(Grille grille,int numeroDeLaPartie,int ** tabScore);

#endif
