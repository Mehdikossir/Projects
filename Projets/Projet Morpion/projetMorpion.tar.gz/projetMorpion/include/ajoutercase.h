
#ifndef AJOUTER_CASE_H
#define AJOUTER_CASE_H
#include "Grille.h"
#include "Case.h"

//static ValeurCase historique[3][3];


void ajoutercase(Grille grille , Coordonnee coord,ValeurCase historique[3][3]);

#endif
