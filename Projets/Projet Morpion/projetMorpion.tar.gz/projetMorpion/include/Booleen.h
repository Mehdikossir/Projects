#ifndef __BOOLEEN__
#define __BOOLEEN__

/** On définie le type Booleen comme étant soit FALSE = 0 soit TRUE = 1*/
typedef enum {FALSE = 0, TRUE = 1} Booleen;

#endif
