#ifndef _CASE_H_
#define _CASE_H_

#include <string.h>
#include "Booleen.h"


/** Le type ValeurCase peu prendre 3 valeurs, soit rien (VIDE),soit ROND
*, soit CROIX*/

typedef enum {VIDE,ROND,CROIX} ValeurCase;

/** Une Case  est defini par le caractère qu'elle comptient, le nombre de points associé
* à cette lettre, le bonus aussi associé et un booleen qui permet de savoir si la
* case a deja été selectionné dans le processus de cases Contigues.*/

typedef struct Case{
	             ValeurCase Valeur;
             Booleen estOccupee;
}Case;

/** C_initialisationCase initialise une case à partir de 2 parametres données.*/
Case C_initialisationCase(ValeurCase Valeur,Booleen estOccupee);
/** C_obtenirLettre obtient la lettre associée à la case.*/
ValeurCase C_obtenirValeur (Case uneCase);
/** C_obtenirBonus obtient le bonus associé à la case.*/
Booleen C_estOccupee(Case uneCase);
/** C_sontEgales permet de savoir si deux cases sont égales.*/
Booleen C_sontEgales(Case uneCase1, Case uneCase2);
#endif
