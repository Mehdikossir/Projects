#include <stdlib.h>
#include <stdio.h>
#include "Case.h"
#include "Booleen.h"

Case C_initialisationCase( ValeurCase Valeur,Booleen estOccupee){
  Case uneCase;
  uneCase.Valeur =Valeur;
  uneCase.estOccupee = estOccupee;
  return uneCase;
}
ValeurCase C_obtenirValeur (Case uneCase){
    return uneCase.Valeur;
}

Booleen C_estOccupee (Case uneCase){
    return uneCase.estOccupee;
}
Booleen C_sontEgales(Case uneCase1, Case uneCase2){
  if ((uneCase1.Valeur == uneCase2.Valeur) && (uneCase1.estOccupee == uneCase2.estOccupee)){
      return TRUE;
  }
      return 0;
}
