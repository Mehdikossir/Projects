#include <stdlib.h>
#include <stdio.h>
#include<assert.h>
#include "FonctionsPrincipales.h"
/* L'algorithme utilise est le plus facile mais n'est pas le plus efficace
    car on n'utilise pas la position du dernier pion ajoute sur la grille. Cette information
    permettrait de reduire le temps de la recherche.
    De plus, cet algo suppose que la taille de la matrice est de 3 par 3
  */
/* si la case 1,1 est VIDE, cela signifie que les diagonales, la ligne 1 et la colonne 1 ne sont
     pas gagnantes
*/
void gagnantExiste(Grille grille,ValeurCase *joueurGagnant,Booleen *estGagnant){
  *estGagnant=FALSE;
  if (grille[1][1].Valeur != VIDE) {
    /* colonne 1 */
   if (((C_sontEgales(grille[0][1],grille[1][1]) && (C_sontEgales(grille[1][1],grille[2][1]))) ||
	/* ligne 1 */ ((C_sontEgales(grille[1][0],grille[1][1])) && (C_sontEgales(grille[1][1],grille[1][2]))) ||
	/* diagonale */ ((C_sontEgales(grille[0][0],grille[1][1])) && (C_sontEgales(grille[1][1],grille[2][2]))) ||
	/* autre diag */ ((C_sontEgales(grille[0][2],grille[1][1])) && (C_sontEgales(grille[1][1],grille[2][0]))))) {
     *joueurGagnant = grille[1][1].Valeur; /* ie ROND ou CROIX */
     *estGagnant = TRUE;
   }
  }

  /* si la case 0,0 est vide, cela signifie que la ligne 0 et le colonne 0 ne sont pas gagnantes */
  if ((!(*estGagnant)) && (grille[0][0].Valeur != VIDE)) {
    if ( /* ligne 0 */ ((C_sontEgales(grille[0][0],grille[0][1])) && (C_sontEgales(grille[0][1],grille[0][2]))) ||
	 /* colonne 0*/ ((C_sontEgales(grille[0][0],grille[1][0])) && (C_sontEgales(grille[1][0],grille[2][0])))) {
      *joueurGagnant = grille[0][0].Valeur;
      *estGagnant = TRUE;
    }
  }

  /* si la case 2,2 est vide, cela signifie que la ligne 2 et la colonne 2 ne sont gagnantes */
  if ((!estGagnant) && (grille[2][2].Valeur != VIDE)) {
    if ( /* ligne 2 */ ((C_sontEgales(grille[2][0],grille[2][1])) && (C_sontEgales(grille[2][1],grille[2][2]))) ||
	 /* colonne 2 */ ((C_sontEgales(grille[0][2],grille[1][2])) && (C_sontEgales(grille[1][2],grille[2][2])))) {
      *joueurGagnant = grille[2][2].Valeur;
      *estGagnant = TRUE;
    }
  }
}

Booleen grillePleine(Grille grille){
  for (unsigned int i=0; i<3; i++) {
    for (unsigned int j=0; j<3; j++) {
      if (grille[i][j].Valeur == VIDE)
	return FALSE;
    }
  }
  return TRUE;

}

Booleen testFinJeu(Grille grille){
 ValeurCase joueurGagnant;
 Booleen estGagnant;
 Booleen estFini=FALSE;
 gagnantExiste(grille,&joueurGagnant,&estGagnant);
 if(estGagnant){
   estFini=TRUE;
 }else{
   if(grillePleine(grille)){
     estFini=TRUE;
   }else{
     estFini=FALSE;
   }
 }
 return estFini;
}

void enregistrerScore(Grille grille,int numeroDeLaPartie,int** tabScore){
  int score1=0;
  int score2=0;
  ValeurCase joueurGagnant;
   Booleen estGagnant;
  gagnantExiste(grille,&joueurGagnant,&estGagnant);
 if(estGagnant){
    if(joueurGagnant==ROND){ //joueur qui utilise le rond c'est la premiére ligne
      tabScore[0][numeroDeLaPartie]=1;
    }else{//joueur qui utilise le croix c'est la deuxiéme ligne
      tabScore[1][numeroDeLaPartie]=1;
    }
 }else{
    if(grillePleine(grille)){
      tabScore[0][numeroDeLaPartie]=0;
      tabScore[1][numeroDeLaPartie]=0;
    }
  }
  for(unsigned int i=0;i<nbDePartie+1;i++){
    score1=score1+tabScore[0][i];
  }
  tabScore[0][nbDePartie]=score1;
  for(unsigned int j=0;j<nbDePartie+1;j++){
    score2=score2+tabScore[1][j];
  }
  tabScore[1][nbDePartie]=score2;
}

void ajoutercase(Grille grille , Coordonnee coord,ValeurCase historique[3][3]){
historique[coord.x][coord.y]=grille[coord.x][coord.y].Valeur;
}
