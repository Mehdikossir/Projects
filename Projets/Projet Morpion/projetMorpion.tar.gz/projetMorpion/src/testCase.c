#include <stdlib.h>
#include <CUnit/Basic.h>
#include "Case.h"
#include "Booleen.h"

int init_suite_success(void) {
  return 0;
}

int clean_suite_success(void) {
  return 0;
}

void test_C_obtenirValeur(void){
  Case uneCase;
  uneCase = C_initialisationCase(ROND,TRUE);
  CU_ASSERT_TRUE(C_obtenirValeur(uneCase)==ROND);
}

void test_C_estOccupee(void){
  Case uneCase;
  uneCase = C_initialisationCase(CROIX,TRUE);
  CU_ASSERT_TRUE(C_estOccupee(uneCase)==TRUE);
}
void test_C_sontEgales(void){
  Case uneCase1, uneCase2;
  uneCase1 = C_initialisationCase(ROND,TRUE);
  uneCase2 = C_initialisationCase(ROND,TRUE);
  CU_ASSERT_TRUE(C_sontEgales(uneCase1,uneCase2)==TRUE);
}


int main(int argc, char** argv){
  CU_pSuite pSuite = NULL;

  /* initialisation du registre de tests */
  if (CUE_SUCCESS != CU_initialize_registry())
    return CU_get_error();

  /* ajout d'une suite de test */
  pSuite = CU_add_suite("Tests boite noire : Case", init_suite_success, clean_suite_success);
  if (NULL == pSuite) {
    CU_cleanup_registry();
    return CU_get_error();
  }

/* Ajout des tests à la suite de tests boite noire */
  if ((NULL == CU_add_test(pSuite, "obtenir Valeur", test_C_obtenirValeur))
      || (NULL == CU_add_test(pSuite, "est deja occupee", test_C_estOccupee))
      || (NULL == CU_add_test(pSuite, "sont egale", test_C_sontEgales))
      )
    {
      CU_cleanup_registry();
      return CU_get_error();
    }

  /* Lancement des tests */
  CU_basic_set_mode(CU_BRM_VERBOSE);
  CU_basic_run_tests();
  printf("\n");
  CU_basic_show_failures(CU_get_failure_list());
  printf("\n\n");

  /* Nettoyage du registre */
  CU_cleanup_registry();
  return CU_get_error();
}
